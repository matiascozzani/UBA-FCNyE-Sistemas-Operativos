#define CMDSEP "END\n"
#define ENDMSG "chau\n"
#define MSGLEN 1024
#define PORT 8001
